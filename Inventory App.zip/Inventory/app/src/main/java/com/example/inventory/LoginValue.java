package com.example.inventory;

public class LoginValue {

    private int mId;
    private String mUsername;
    private String mPassword;


    // public getter methods

    public String getUsername() {
        return mUsername;
    }

    public String getPassword() {
        return mPassword;
    }



    // public setter methods

    public void setUsername(String username) {
        mUsername = username;
    }

    public void setPassword(String password) {
        mPassword = password;
    }
}
